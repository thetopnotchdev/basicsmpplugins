#!/usr/bin/env bash
# Boots a real Paper server with the plugin, fires console commands, and fails on plugin errors.
set -euo pipefail
VER=1.21.4
rm -rf run && mkdir -p run/plugins && cd run
BUILD=$(curl -s "https://api.papermc.io/v2/projects/paper/versions/$VER/builds" | jq -r '.builds[-1].build')
curl -fL -o paper.jar "https://api.papermc.io/v2/projects/paper/versions/$VER/builds/$BUILD/downloads/paper-$VER-$BUILD.jar"
echo "eula=true" > eula.txt
echo "online-mode=false" > server.properties
cp ../target/BasicSMP-*.jar plugins/

mkfifo in.pipe
java -Xmx2G -jar paper.jar nogui < in.pipe > server.log 2>&1 &
PID=$!
exec 3> in.pipe

for i in $(seq 1 180); do grep -q 'Done (' server.log && break; sleep 1; done
grep -q 'Done (' server.log || { cat server.log; echo "server never started"; exit 1; }

echo "enchantrotation status" >&3; sleep 2
echo "enchantrotation now" >&3; sleep 2
echo "enchantrotation reload" >&3; sleep 2
echo "stop" >&3
wait $PID || true

cat server.log
grep -q 'BasicSMP enabled' server.log || { echo "plugin did not enable"; exit 1; }
if grep -E 'Could not load|Error occurred|Exception|Unknown enchant in pool' server.log | grep -i -E 'basicsmp|jitnation|Unknown enchant'; then
  echo "plugin errors found"; exit 1
fi
echo "SMOKE TEST PASSED"
